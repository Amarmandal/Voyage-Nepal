import React, { Component } from 'react';
import {View,Text,Stylesheet, ScrollView} from 'react-native';
import Colors from '../../../constants/Color'
import Icon from 'react-native-vector-icons'

const Detail =({navigation,route})=>{
    const items=route.param;
    return(
        <ScrollView showsVerticalScrollIndicator={false}>
            <View style={{marginTop:20}}>
                <Text style={{fontSize: 22}}>{item.details}</Text>
            </View>
        </ScrollView>
    )
}

export default Detail
