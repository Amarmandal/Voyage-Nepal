import React, { Component } from 'react';
import { Container, Header, Tab, Tabs, TabHeading, Icon, Text } from 'native-base';
import ImageDetail from './image'
import Detail from './Detail';
import Review from './Review';
import Hotel from './Hotel';
const DetailScreen =(navigation) =>{
  render() {
    return (
      <Container>
        <Header>
        <ImageDetail />
        </Header>
        <Tabs>
          <Tab heading="Details">
            <Detail />
          </Tab>
          <Tab heading="Review">
            <Review />
          </Tab>
          <Tab heading="Hotels">
            <Hotel />
          </Tab>
        </Tabs>
      </Container>
    );
  }
}

export default DetailScreen;