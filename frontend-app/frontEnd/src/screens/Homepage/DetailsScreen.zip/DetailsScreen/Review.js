import React, { Component } from 'react';
import { Container, Header, Content, Card, CardItem, Body, Text } from 'native-base';
const Review=({navigation}=>) {
  render() {
    return (
      <Container>
        <Content showsVerticalScrollIndicator = {false}>
          <Card>
            <CardItem bordered>
            <Left>
            <Thumbnail  source={require('../../../assets/pictures/face.jpg')} style={{width: 80, height: 80}}/>
                <Body><Text style = {{fontSize: 20,color: Colors.warning}}>
                   John Doe
                </Text></Body>
            </Left>
              <Body>
                
                <Text note style = {{fontSize: 18}}>Loreum ipsum Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</Text>
                
                <View style = {{flexDirection: 'row'}}>
                  <Icon type="FontAwesome" name="star" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star-half-empty" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star-o" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                </View>
              </Body>
            </CardItem>
             <CardItem bordered>
             <Left>
            <Thumbnail  source={require('../../../assets/pictures/face.jpg')} style={{width: 80, height: 80}}/>
                <Body><Text style = {{fontSize: 20,color: Colors.warning}}>
                   John Doe
                </Text></Body>
            </Left>
              <Body>
                
                <Text note style = {{fontSize: 18}}>Loreum ipsum Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</Text>
                
                <View style = {{flexDirection: 'row'}}>
                  <Icon type="FontAwesome" name="star" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star-half-empty" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star-o" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                </View>
              </Body>
            </CardItem>
             <CardItem bordered>
             <Left>
            <Thumbnail  source={require('../../../assets/pictures/face.jpg')} style={{width: 80, height: 80}}/>
                <Body><Text style = {{fontSize: 20,color: Colors.warning}}>
                   John Doe
                </Text></Body>
            </Left>
              <Body>
                
                <Text note style = {{fontSize: 18}}>Loreum ipsum Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</Text>
                
                <View style = {{flexDirection: 'row'}}>
                  <Icon type="FontAwesome" name="star" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star-half-empty" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                  <Icon type="FontAwesome" name="star-o" style = {{color: Colors.warning, marginRight: 3, fontSize: 22}}/>
                </View>
              </Body>
            </CardItem>
          </Card>
        </Content>
      </Container>
    );
  }
}

export default Review